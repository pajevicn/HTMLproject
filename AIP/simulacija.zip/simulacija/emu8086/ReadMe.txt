
===================================================================================================

Please enable Windows XP compatibly mode!

===================================================================================================


Windows XP compatibly mode must be applied to "EMU8086.exe" and to all virtual hardware devices.

To minimize incompatibly problems, run all files as administrator.

===================================================================================================


READ/WRITE access should be granted to files at these locations:

C:\emu8086.io
C:\emu8086.hw

===================================================================================================


For technical support email: info@emu8086.com 


===================================================================================================



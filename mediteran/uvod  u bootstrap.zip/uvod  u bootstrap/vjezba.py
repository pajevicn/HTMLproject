 print("nikola")
